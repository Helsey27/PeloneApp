document.addEventListener('DOMContentLoaded', function () {
    const logoutButton = document.getElementById('logoutButton');

    if (logoutButton) {
        console.log("Logout button found!"); // Add this line
        logoutButton.addEventListener('click', function () {
            console.log("Logout button clicked!"); // Add this line
            localStorage.removeItem('loggedInUser');
            sessionStorage.removeItem('isLoggedIn');
            window.location.href = "index.html";
            console.log("Redirecting to index.html"); // Add this line
        });
    } else {
        console.error("Logout button not found!");
    }
});