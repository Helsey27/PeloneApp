// script.js

// Function to open a site in a new tab
function openSite(url) {
    window.open(url, '_blank');
}

// Function to perform a search
function performSearch() {
    const query = document.getElementById("searchInput").value;
    if (query.trim() !== "") {
        window.location.href = `results.html?q=${encodeURIComponent(query)}`;
    }
}

// Function to go to settings page
function goToSettings() {
    window.location.href = "settings.html";
}

// Function to go to the homepage
function goToHome() {
    const mainContent = document.getElementById("main-content");
    mainContent.classList.remove("show");
    setTimeout(() => {
        window.location.href = "index.html";
    }, 500); // Match the transition duration
}

function displayStartupMessage() {
    if (sessionStorage.getItem('startupMessageDisplayed') !== 'true') {
        alert("This application is free to use. © HPelone2025");
        sessionStorage.setItem('startupMessageDisplayed', 'true');
    }
}

// Main application logic
window.onload = () => {
    // Get references to DOM elements
    const authScreen = document.getElementById("auth-screen");
    const authForm = document.getElementById("auth-form");
    const authTitle = document.getElementById("auth-title");
    const authButton = document.getElementById("auth-button");
    const toggleAuthMode = document.getElementById("toggle-auth-mode");
    const splashScreen = document.getElementById("splash-screen");
    const mainContent = document.getElementById("main-content");
    const splashSound = document.getElementById('splashSound');
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");

    // Authentication mode (login or register)
    let isLoginMode = true;
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers')) || {};
    const loggedInUser = localStorage.getItem('loggedInUser'); // Get stored username

    // Display startup message
    displayStartupMessage();

    // Check if splash screen has been shown this session
    if (sessionStorage.getItem('splashShown') === null) {
        // Show splash screen and set session storage item
        splashSound.play();
        setTimeout(() => {
            splashScreen.style.display = "none";
            sessionStorage.setItem('splashShown', 'true');

            // Skip login and show main content if logged in
            if (loggedInUser && registeredUsers[loggedInUser]) { // Check stored username
                authScreen.style.display = "none";
                mainContent.classList.add("show");
                displayUserGreeting(loggedInUser);
            } else {
                // Show login/register screen
                authScreen.classList.add("show");
            }
        }, 3000);
    } else {
        // Splash screen has already been shown, skip it
        splashScreen.style.display = "none";

        // Skip login and show main content if logged in
        if (loggedInUser && registeredUsers[loggedInUser]) { // Check stored username
            authScreen.style.display = "none";
            mainContent.classList.add("show");
            displayUserGreeting(loggedInUser);
        } else {
            // Show login/register screen
            authScreen.classList.add("show");
        }
    }

    // Function to display the user greeting
    function displayUserGreeting(username) {
        const savedName = localStorage.getItem("peloneUserName");
        const displayName = savedName || username;
        document.getElementById("userGreeting").textContent = `Hello, ${displayName}!`;
    }

    // Background music logic
    const backgroundMusic = document.getElementById("backgroundMusic");
    backgroundMusic.volume = 0.01; // Set volume to 1%

    function playMusic() {
        try {
            backgroundMusic.play();
        } catch (error) {
            console.error("Failed to play music:", error);
        }
    }

    // Attempt to play music on first user interaction
    document.addEventListener("click", playMusic, {
        once: true
    });
    document.addEventListener("touchstart", playMusic, {
        once: true
    });

    // Function to switch between login and register modes
    function switchAuthMode() {
        isLoginMode = !isLoginMode;
        authTitle.textContent = isLoginMode ? "Login" : "Register";
        authButton.textContent = isLoginMode ? "Login" : "Register";
        toggleAuthMode.innerHTML = isLoginMode
            ? "Don't have an account? <a>Register</a>"
            : "Already have an account? <a>Login</a>";
    }

    // Event listener for switching between login and register
    toggleAuthMode.addEventListener("click", (event) => {
        if (event.target.tagName === "A") {
            event.preventDefault();
            switchAuthMode();
        }
    });

    // Event listener for the auth (login/register) button
    authButton.addEventListener("click", () => {
        const username = usernameInput.value;
        const password = passwordInput.value;

        // Input validation
        if (username.trim() === "" || password.trim() === "") {
            alert("Please enter both username and password.");
            return; // Stop the login/registration process
        }

        if (isLoginMode) {
            // Login Logic
            if (registeredUsers[username] && registeredUsers[username] === password) {
                // Successful login
                authScreen.style.display = "none";
                mainContent.classList.add("show");
                localStorage.setItem('loggedInUser', username); // Store username
                sessionStorage.setItem('isLoggedIn', 'true');

                displayUserGreeting(username);
            } else {
                alert("Invalid username or password");
            }
        } else {
            // Registration Logic
            if (registeredUsers[username]) {
                alert("Username already exists. Please choose a different username.");
            } else {
                // Simulate successful registration
                //WARNING: Client-side hashing is NOT secure and is only for demonstration purposes. A backend is required for real security.
                const shaObj = new jsSHA("SHA-256", "TEXT");
                shaObj.update(password);
                const hashedPassword = shaObj.getHash("HEX");

                registeredUsers[username] = hashedPassword;
                localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
                alert("Registration successful. Please log in.");
                switchAuthMode(); // Switch back to login mode
            }
        }
    });

    // Forgot Password (Simulated)
    document.getElementById("forgot-password-link").addEventListener("click", (event) => {
        event.preventDefault();
        const username = document.getElementById("username").value;

        if (registeredUsers[username]) {
            alert("A password reset link has been sent to your email address (simulated).");
        } else {
            alert("Username not found.");
        }
    });

    // Function to get and display the username
    function getUsername() {
        // Try to get the peloneUserName first
        let username = localStorage.getItem('peloneUserName');

        // If peloneUserName doesn't exist, fall back to loggedInUser or 'Guest'
        if (!username) {
            username = localStorage.getItem('loggedInUser') || 'Guest';
        }

        document.getElementById('userGreeting').textContent = `Hello, ${username}!`;
    }

    // Call these functions on window load
    getUsername();
};